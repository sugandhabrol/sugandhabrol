from django.contrib import admin
from home.models import Task

# Register your models here.
admin.site.register(Task)
